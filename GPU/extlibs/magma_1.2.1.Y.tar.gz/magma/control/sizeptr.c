#include <stdio.h>

int main()
{
    int size = sizeof(void*);
    printf("%d", size);
    return 0;
}
